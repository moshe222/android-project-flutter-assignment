package com.example.startup_moshe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
